#ifndef CRACK
#define CRACK

// had to make shorter than 10k as it wanst functioning on VM and would break
// some functions, likely due to memory problems
#define PWLENGTH 50

void chop(char *word);
void string2ByteArray(char* input, BYTE* output);
void ReadFile(char *name, char* buffer);
void checkpw(BYTE text[], char * fname);
void crack4chars(char*fileName);
void brute6chars(char*fileName);
int guessing(int nguesses);
int capitalise_guess(FILE * words, int count,int nguesses, int element);
int replace_guess_with_num(FILE * words, int count, int nguesses, int element);

#endif
